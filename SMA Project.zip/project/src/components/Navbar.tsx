import React from 'react';
import { Menu, X, Home, Users, BarChart3, MessageSquare, ShoppingBag, Phone, Building2, User } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const navigation = [
    { name: 'Home', href: '/', icon: Home },
    { name: 'Modules', href: '/modules', icon: Users },
    { name: 'Dashboard', href: '/dashboard', icon: BarChart3 },
    { name: 'Communication', href: '/communication', icon: MessageSquare },
    { name: 'Marketplace', href: '/marketplace', icon: ShoppingBag },
    { name: 'Features', href: '/features', icon: BarChart3 },
    { name: 'Get Started', href: '/get-started', icon: Phone },
    { name: 'Founder', href: '/founder', icon: User },
  ];

  return (
    <nav className="bg-gradient-to-r from-black via-gray-900 to-black shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-2">
            <Link to="/" className="flex items-center space-x-2">
              <Building2 className="h-8 w-8 text-yellow-400" />
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-yellow-400 tracking-wider">SMA</span>
                <span className="text-xs text-yellow-200">Society Management Assistant</span>
              </div>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-gray-300 hover:text-yellow-400 px-3 py-2 rounded-md text-sm font-medium flex items-center gap-1 transition-colors duration-200"
              >
                <item.icon className="h-4 w-4" />
                {item.name}
              </Link>
            ))}
          </div>

          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 hover:text-yellow-400"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-gradient-to-r from-black via-gray-900 to-black">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="text-gray-300 hover:text-yellow-400 block px-3 py-2 rounded-md text-base font-medium flex items-center gap-2 transition-colors duration-200"
                onClick={() => setIsOpen(false)}
              >
                <item.icon className="h-5 w-5" />
                {item.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;