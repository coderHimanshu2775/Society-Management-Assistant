import React from 'react';
import {
  Shield,
  Users,
  Clock,
  Database,
  Bell,
  CreditCard,
  Building,
  Car,
  MessageSquare,
  Settings,
  Calendar,
  FileText
} from 'lucide-react';

const Features = () => {
  const features = [
    {
      name: 'Data Storage & Privacy',
      description: 'Secure AWS-based storage with end-to-end encryption and GDPR compliance.',
      icon: Database,
      href: '/features/data-privacy'
    },
    {
      name: 'Security Management',
      description: 'Advanced visitor tracking, CCTV integration, and real-time alerts.',
      icon: Shield,
      href: '/features/security'
    },
    {
      name: 'Admin Dashboard',
      description: 'Comprehensive analytics and control panel for society administrators.',
      icon: Users,
      href: '/features/admin'
    },
    {
      name: 'Vehicle Management',
      description: 'Digital parking allocation and vehicle tracking system.',
      icon: Car,
      href: '/features/vehicle'
    },
    {
      name: 'Communication Hub',
      description: 'Integrated platform for notices, polls, and resident communication.',
      icon: MessageSquare,
      href: '/features/communication'
    },
    {
      name: 'Complaint System',
      description: 'Streamlined complaint registration and resolution tracking.',
      icon: FileText,
      href: '/features/complaints'
    },
    {
      name: 'Amenity Booking',
      description: 'Easy booking system for community facilities and amenities.',
      icon: Calendar,
      href: '/features/amenities'
    },
    {
      name: 'Payment Portal',
      description: 'Secure payment gateway for maintenance and utility bills.',
      icon: CreditCard,
      href: '/features/payments'
    },
    {
      name: 'Property Marketplace',
      description: 'Platform for rental and sale listings within the community.',
      icon: Building,
      href: '/features/marketplace'
    }
  ];

  return (
    <div className="py-24 bg-gradient-to-br from-gray-100 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-black sm:text-4xl">
            Comprehensive Society Management
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
            Everything you need to manage your society efficiently and effectively,
            all in one integrated platform.
          </p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <a
                key={feature.name}
                href={feature.href}
                className="group transform hover:scale-105 transition-transform duration-200"
              >
                <div className="h-full pt-6">
                  <div className="flow-root bg-white rounded-lg px-6 pb-8 h-full hover:shadow-xl transition-shadow duration-200 border border-gray-100">
                    <div className="-mt-6">
                      <div>
                        <span className="inline-flex items-center justify-center p-3 bg-gradient-to-r from-black to-gray-900 group-hover:from-yellow-500 group-hover:to-yellow-400 rounded-md shadow-lg transition-colors duration-200">
                          <feature.icon className="h-6 w-6 text-white" aria-hidden="true" />
                        </span>
                      </div>
                      <h3 className="mt-8 text-lg font-medium text-gray-900 tracking-tight group-hover:text-yellow-600 transition-colors duration-200">
                        {feature.name}
                      </h3>
                      <p className="mt-5 text-base text-gray-500">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;