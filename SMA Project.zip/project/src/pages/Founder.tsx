import React from 'react';
import { Mail, Linkedin, Github } from 'lucide-react';

const Founder = () => {
  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gray-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="relative h-40 bg-gradient-to-r from-yellow-400 to-yellow-600">
            <div className="absolute -bottom-16 left-1/2 transform -translate-x-1/2">
              <img
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&h=200&q=80"
                alt="Himanshu Singh"
                className="w-32 h-32 rounded-full border-4 border-gray-800"
              />
            </div>
          </div>
          
          <div className="pt-20 pb-8 px-6 text-center">
            <h1 className="text-3xl font-bold text-yellow-400 mb-2">Himanshu Singh</h1>
            <p className="text-gray-400 mb-4">Founder of SMA (Society Management Assistant)</p>
            
            <div className="flex justify-center space-x-4 mb-8">
              <a href="mailto:co.himanshu95699@gmail.com" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Mail className="h-6 w-6" />
              </a>
              <a href="https://linkedin.com/in/himanshu2403" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://github.com/coderHimanshu2775" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Github className="h-6 w-6" />
              </a>
            </div>

            <div className="prose prose-lg text-gray-300 max-w-none">
              <p className="mb-4">
                Himanshu Singh is the visionary behind SMA (Society Management Assistant), a platform dedicated to simplifying 
                and enhancing society and residential management through technology. With a strong background in Computer Science 
                and Engineering, he is passionate about creating innovative digital solutions that improve community living.
              </p>
              
              <p className="mb-4">
                Currently pursuing his B.Tech in Computer Science and Engineering at Lovely Professional University, Himanshu has 
                developed expertise in C++, Java, Python, Web Development, and Automation Testing. His technical proficiency spans 
                across frameworks like HTML, CSS, JavaScript, SQL, and tools such as Selenium, Appium, and Postman.
              </p>

              <p className="mb-4">
                His professional journey includes an internship at AADMEX, where he contributed to market research, client 
                acquisition, and business growth. He has also built projects like an Electric Vehicle Info Website, optimizing 
                real-time data processing and enhancing user experience.
              </p>

              <p>
                With SMA (Society Management Assistant), Himanshu aims to bridge the gap between technology and efficient 
                residential management, offering smart, user-friendly solutions to streamline day-to-day operations in societies 
                and apartments.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Founder;