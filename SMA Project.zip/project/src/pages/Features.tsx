import React from 'react';
import { Shield, Users, Clock, Database, Bell, CreditCard, Building, Car, MessageSquare, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

const Features = () => {
  const features = [
    {
      title: 'Advanced Security',
      description: 'State-of-the-art security features with visitor tracking and CCTV integration',
      icon: Shield,
      color: 'from-red-500 to-red-600'
    },
    {
      title: 'Community Management',
      description: 'Comprehensive resident directory and community engagement tools',
      icon: Users,
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Real-time Updates',
      description: 'Instant notifications and updates for all community activities',
      icon: Bell,
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      title: 'Digital Payments',
      description: 'Secure and convenient payment gateway for all transactions',
      icon: CreditCard,
      color: 'from-green-500 to-green-600'
    },
    {
      title: 'Vehicle Management',
      description: 'Digital parking allocation and vehicle tracking system',
      icon: Car,
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: 'Communication Hub',
      description: 'Centralized platform for all community communications',
      icon: MessageSquare,
      color: 'from-indigo-500 to-indigo-600'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-yellow-400 mb-4">Our Features</h1>
          <p className="text-gray-300 text-lg">Discover the powerful tools that make community management effortless</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-gray-800 rounded-lg p-6 transform hover:scale-105 transition-transform duration-300"
            >
              <div className={`bg-gradient-to-r ${feature.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <feature.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-yellow-400 mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            to="/get-started"
            className="inline-flex items-center px-6 py-3 bg-yellow-400 text-black rounded-lg hover:bg-yellow-300 transition-colors duration-200"
          >
            Get Started Now
            <svg className="ml-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Features;