import React from 'react';
import { Shield, Users, Clock, Bell, CreditCard, Building } from 'lucide-react';

const Modules = () => {
  const modules = [
    {
      title: 'Security Management',
      description: 'Advanced security features including visitor tracking and CCTV monitoring',
      icon: Shield,
      color: 'bg-red-500'
    },
    {
      title: 'Resident Directory',
      description: 'Complete database of all residents with contact information',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      title: 'Maintenance Scheduling',
      description: 'Schedule and track regular maintenance activities',
      icon: Clock,
      color: 'bg-green-500'
    },
    {
      title: 'Notice Board',
      description: 'Digital notice board for important announcements',
      icon: Bell,
      color: 'bg-purple-500'
    },
    {
      title: 'Payment Management',
      description: 'Handle maintenance fees and other payments',
      icon: CreditCard,
      color: 'bg-yellow-500'
    },
    {
      title: 'Facility Booking',
      description: 'Book common facilities and track usage',
      icon: Building,
      color: 'bg-indigo-500'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-yellow-400 mb-4">Our Modules</h1>
          <p className="text-gray-300 text-lg mb-12">Comprehensive solutions for efficient society management</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {modules.map((module, index) => (
            <div
              key={index}
              className="bg-gray-800 rounded-lg p-6 transform hover:scale-105 transition-transform duration-300"
            >
              <div className={`${module.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                <module.icon className="h-6 w-6 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-yellow-400 mb-2">{module.title}</h3>
              <p className="text-gray-400">{module.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Modules;