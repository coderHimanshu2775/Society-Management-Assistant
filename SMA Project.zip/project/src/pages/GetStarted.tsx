import React from 'react';
import { CheckCircle } from 'lucide-react';

const GetStarted = () => {
  const steps = [
    {
      title: 'Create an Account',
      description: 'Sign up with your email and basic information to get started.'
    },
    {
      title: 'Complete Society Profile',
      description: 'Add your society details, including location and amenities.'
    },
    {
      title: 'Invite Residents',
      description: 'Send invitations to all society members to join the platform.'
    },
    {
      title: 'Start Managing',
      description: 'Begin using the features to manage your society effectively.'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-yellow-400 mb-4">Get Started with SMA</h1>
          <p className="text-gray-300 text-lg">Follow these simple steps to set up your society management system</p>
        </div>

        <div className="max-w-3xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="flex items-start mb-8">
              <div className="flex-shrink-0 bg-yellow-400 rounded-full p-2">
                <CheckCircle className="h-6 w-6 text-black" />
              </div>
              <div className="ml-4">
                <h3 className="text-xl font-semibold text-yellow-400 mb-2">
                  Step {index + 1}: {step.title}
                </h3>
                <p className="text-gray-400">{step.description}</p>
              </div>
            </div>
          ))}

          <div className="mt-12 text-center">
            <button className="px-8 py-4 bg-yellow-400 text-black rounded-lg text-lg font-semibold hover:bg-yellow-300 transition-colors duration-200">
              Register Your Society
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetStarted;