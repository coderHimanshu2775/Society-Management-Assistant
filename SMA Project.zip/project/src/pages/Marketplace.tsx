import React from 'react';
import { Home, Tag, Search } from 'lucide-react';

const Marketplace = () => {
  const listings = [
    {
      type: 'Rent',
      title: '3 BHK Apartment',
      location: 'Block A, 3rd Floor',
      price: '₹25,000/month',
      amenities: ['Furnished', 'Parking', 'Security'],
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80'
    },
    {
      type: 'Sale',
      title: '2 BHK Apartment',
      location: 'Block B, 5th Floor',
      price: '₹65,00,000',
      amenities: ['Semi-Furnished', 'Parking', 'Garden View'],
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80'
    },
    {
      type: 'Rent',
      title: '4 BHK Penthouse',
      location: 'Block C, Top Floor',
      price: '₹45,000/month',
      amenities: ['Fully Furnished', 'Terrace', 'Premium'],
      image: 'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80'
    }
  ];

  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-yellow-400">Property Marketplace</h1>
          <p className="text-gray-400">Find your next home within the community</p>
        </div>

        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search properties..."
                  className="w-full bg-gray-800 text-gray-300 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
              </div>
            </div>
            <div className="flex gap-4">
              <select className="bg-gray-800 text-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400">
                <option>All Types</option>
                <option>For Rent</option>
                <option>For Sale</option>
              </select>
              <select className="bg-gray-800 text-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400">
                <option>Price Range</option>
                <option>₹0 - ₹20,000</option>
                <option>₹20,000 - ₹40,000</option>
                <option>₹40,000+</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {listings.map((listing, index) => (
            <div key={index} className="bg-gray-800 rounded-lg overflow-hidden">
              <img
                src={listing.image}
                alt={listing.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    listing.type === 'Rent' ? 'bg-blue-500 text-white' : 'bg-green-500 text-white'
                  }`}>
                    {listing.type}
                  </span>
                  <span className="text-yellow-400 font-bold">{listing.price}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-300 mb-2">{listing.title}</h3>
                <p className="text-gray-400 flex items-center mb-4">
                  <Home className="h-4 w-4 mr-2" />
                  {listing.location}
                </p>
                <div className="flex flex-wrap gap-2">
                  {listing.amenities.map((amenity, i) => (
                    <span key={i} className="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm flex items-center">
                      <Tag className="h-3 w-3 mr-1" />
                      {amenity}
                    </span>
                  ))}
                </div>
                <button className="w-full mt-6 bg-yellow-400 text-black rounded-lg px-4 py-2 hover:bg-yellow-300 transition-colors">
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Marketplace;