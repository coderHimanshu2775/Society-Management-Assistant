import React from 'react';
import { MessageSquare, Bell, Users, Send } from 'lucide-react';

const Communication = () => {
  return (
    <div className="bg-gradient-to-br from-gray-900 to-black min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-yellow-400">Communication Hub</h1>
          <p className="text-gray-400">Stay connected with your community</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg p-6 mb-8">
              <h2 className="text-xl font-semibold text-yellow-400 mb-4">Community Chat</h2>
              <div className="space-y-4 mb-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-gray-700 rounded-full p-2">
                    <Users className="h-5 w-5 text-yellow-400" />
                  </div>
                  <div className="flex-1 bg-gray-700 rounded-lg p-4">
                    <p className="text-sm text-gray-300">Admin</p>
                    <p className="text-gray-400">Welcome to our community chat! Feel free to discuss any society-related matters here.</p>
                  </div>
                </div>
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Type your message..."
                  className="flex-1 bg-gray-700 text-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                />
                <button className="bg-yellow-400 text-black rounded-lg px-4 py-2 hover:bg-yellow-300 transition-colors">
                  <Send className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-yellow-400 mb-4">Announcements</h2>
              <div className="space-y-4">
                <div className="border-l-4 border-yellow-400 pl-4">
                  <p className="text-gray-300 font-semibold">Monthly Meeting</p>
                  <p className="text-gray-400">Monthly society meeting scheduled for this Sunday at 11 AM.</p>
                  <p className="text-sm text-gray-500">2 hours ago</p>
                </div>
                <div className="border-l-4 border-blue-400 pl-4">
                  <p className="text-gray-300 font-semibold">Maintenance Notice</p>
                  <p className="text-gray-400">Water supply will be interrupted tomorrow from 10 AM to 2 PM.</p>
                  <p className="text-sm text-gray-500">1 day ago</p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-yellow-400 mb-4">Quick Actions</h2>
              <div className="space-y-4">
                <button className="w-full bg-gray-700 text-gray-300 rounded-lg px-4 py-3 hover:bg-gray-600 transition-colors flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  New Message
                </button>
                <button className="w-full bg-gray-700 text-gray-300 rounded-lg px-4 py-3 hover:bg-gray-600 transition-colors flex items-center">
                  <Bell className="h-5 w-5 mr-2" />
                  Create Announcement
                </button>
              </div>
            </div>

            <div className="bg-gray-800 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-yellow-400 mb-4">Active Users</h2>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-green-500 h-2 w-2 rounded-full mr-2"></div>
                  <span className="text-gray-300">John Doe</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-green-500 h-2 w-2 rounded-full mr-2"></div>
                  <span className="text-gray-300">Jane Smith</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-gray-500 h-2 w-2 rounded-full mr-2"></div>
                  <span className="text-gray-400">Mike Johnson</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Communication;