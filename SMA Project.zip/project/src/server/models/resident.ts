import mongoose from 'mongoose';
import { IResident } from '../types';

const residentSchema = new mongoose.Schema<IResident>({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, required: true },
  flatNumber: { type: String, required: true },
  role: { type: String, enum: ['Resident', 'Admin'], default: 'Resident' }
});

export const Resident = mongoose.model<IResident>('Resident', residentSchema);