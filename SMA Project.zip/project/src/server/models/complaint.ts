import mongoose from 'mongoose';
import { IComplaint } from '../types';

const complaintSchema = new mongoose.Schema<IComplaint>({
  title: { type: String, required: true },
  description: { type: String, required: true },
  status: { 
    type: String, 
    enum: ['Open', 'In Progress', 'Resolved'], 
    default: 'Open' 
  },
  residentId: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Resident',
    required: true 
  },
  createdAt: { type: Date, default: Date.now }
});

export const Complaint = mongoose.model<IComplaint>('Complaint', complaintSchema);