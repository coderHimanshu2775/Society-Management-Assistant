import { Document } from 'mongoose';

export interface IResident extends Document {
  name: string;
  email: string;
  phone: string;
  flatNumber: string;
  role: 'Resident' | 'Admin';
}

export interface IComplaint extends Document {
  title: string;
  description: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  residentId: IResident['_id'];
  createdAt: Date;
}