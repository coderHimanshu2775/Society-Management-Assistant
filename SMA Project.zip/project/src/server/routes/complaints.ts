import { Router } from 'express';
import { Complaint } from '../models/complaint';

const router = Router();

router.post('/create', async (req, res) => {
  try {
    const { title, description, residentId } = req.body;
    const complaint = new Complaint({ title, description, residentId });
    await complaint.save();
    res.status(201).json({ message: 'Complaint created successfully', complaint });
  } catch (error) {
    res.status(500).json({ message: 'Error creating complaint', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const complaints = await Complaint.find().populate('residentId', 'name flatNumber');
    res.status(200).json(complaints);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching complaints', error });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { status } = req.body;
    const complaint = await Complaint.findByIdAndUpdate(
      req.params.id, 
      { status }, 
      { new: true }
    ).populate('residentId', 'name flatNumber');
    
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }
    
    res.status(200).json({ message: 'Complaint updated successfully', complaint });
  } catch (error) {
    res.status(500).json({ message: 'Error updating complaint', error });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndDelete(req.params.id);
    
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }
    
    res.status(200).json({ message: 'Complaint deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting complaint', error });
  }
});

export default router;