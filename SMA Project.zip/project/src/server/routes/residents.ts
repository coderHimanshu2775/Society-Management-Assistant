import { Router } from 'express';
import { Resident } from '../models/resident';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, email, phone, flatNumber, role } = req.body;
    const resident = new Resident({ name, email, phone, flatNumber, role });
    await resident.save();
    res.status(201).json({ message: 'Resident registered successfully', resident });
  } catch (error) {
    res.status(500).json({ message: 'Error registering resident', error });
  }
});

router.get('/', async (req, res) => {
  try {
    const residents = await Resident.find();
    res.status(200).json(residents);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching residents', error });
  }
});

export default router;