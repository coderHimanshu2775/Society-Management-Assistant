import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Modules from './pages/Modules';
import Dashboard from './pages/Dashboard';
import Communication from './pages/Communication';
import Marketplace from './pages/Marketplace';
import Features from './pages/Features';
import GetStarted from './pages/GetStarted';
import Founder from './pages/Founder';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white flex flex-col">
        <Navbar />
        <main className="flex-grow pt-16">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/modules" element={<Modules />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/communication" element={<Communication />} />
            <Route path="/marketplace" element={<Marketplace />} />
            <Route path="/features" element={<Features />} />
            <Route path="/get-started" element={<GetStarted />} />
            <Route path="/founder" element={<Founder />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;